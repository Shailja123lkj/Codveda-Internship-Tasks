#This my next task of basic level
#internship task from Codveda
#Gussing game : Guess the number in range 1-100, and see how much you can predict :-)

#This will help to generate random numbers for game
import random

#Defining the game pattern
def number_guessing_game():
    # Generate a random number between 1 and 100
    target_number = random.randint(1, 100)
    # basically at start 0 attempts
    attempts = 0
    print("Welcome to the Number Guessing Game!\nLet's see your gussing level!")
    print("I have picked a number between 1-100\nIt's your turn to guess the number")
    print("Can you guess what it is?")

    while True:
        try:
            # Get user's guess
            guess = int(input("What's your guess?: "))
            attempts += 1

            # Check the guess
            if guess < target_number:
                print("Oops!Your guess is Too low! Try again.")
            elif guess > target_number:
                print("Oops!Your guess is Too high! Try again.")
            else:
                print(f"Yay! You guessed it right in {attempts} attempts.")
                break
        except ValueError:
            print("Hey! Your input is invalid.Try again.")

# Run the game
number_guessing_game()
